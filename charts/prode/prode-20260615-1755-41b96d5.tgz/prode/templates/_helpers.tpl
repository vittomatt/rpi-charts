{{- define "prode.datadogLabels" -}}
{{- $root := .root -}}
tags.datadoghq.com/env: {{ $root.Values.observability.env | quote }}
tags.datadoghq.com/service: {{ .service | quote }}
tags.datadoghq.com/version: {{ $root.Values.releaseVersion | quote }}
{{- end -}}

{{- define "prode.datadogEnv" -}}
{{- $root := .root -}}
- name: DD_ENV
  valueFrom:
    fieldRef:
      fieldPath: metadata.labels['tags.datadoghq.com/env']
- name: DD_SERVICE
  valueFrom:
    fieldRef:
      fieldPath: metadata.labels['tags.datadoghq.com/service']
- name: DD_VERSION
  valueFrom:
    fieldRef:
      fieldPath: metadata.labels['tags.datadoghq.com/version']
- name: DD_AGENT_HOST
  valueFrom:
    fieldRef:
      fieldPath: status.hostIP
- name: DD_TRACE_AGENT_PORT
  value: {{ $root.Values.observability.datadog.traceAgentPort | quote }}
- name: DD_LOGS_INJECTION
  value: {{ $root.Values.observability.datadog.logsInjection | quote }}
- name: DD_RUNTIME_METRICS_ENABLED
  value: {{ $root.Values.observability.datadog.runtimeMetrics | quote }}
{{- end -}}
